/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDD;

/**
 *
 * @author Nicola
 */
public class Pila<T> {

    private Nodo<T> Bottom;
    private Nodo<T> Top;
    private int size;

    public Pila() {
        this.Bottom = this.Top = null;
        this.size = 0;
    }

    public boolean isEmpty() {
        return Top == null;
    }

    public void Empty() {
        this.Bottom = this.Top = null;
        this.size = 0;
    }

    /**
     * verifica si un elemento esta en la pila o no
     * @param data
     * @return
     */
    public boolean enLaPila(T data){
        boolean presente = false;
    Nodo<T> aux = Top;
    while(aux!=null){
        if(aux.getData()==data){
        presente = true;
        break;
        }
    aux=aux.getpNext();
    }
    return presente;
}

    /**
     * Apila un elemento en la pila
     * @param data
     */
    public void apilar(T data) {

        Nodo<T> nuevo = new Nodo<>(data);
        if (isEmpty()) {
            Bottom = nuevo;
            Top = nuevo;
            size += 1;
        } else {
            Nodo<T> revision = Top;
            while (revision != null && revision.getData() != nuevo.getData()) {
                revision = revision.getpNext();
            }
            if (revision == null) {
                Nodo aux = Top;
                nuevo.setpNext(aux);
                Top = nuevo;
                size += 1;
            }
        }
    }
    
    /**
     *  desapila el elemento tope de la pila
     */
    public void Desapilar() {
        if (!isEmpty()) {
            Top = Top.getpNext();
            size -= 1;
        }
    }

    public Nodo<T> getBottom() {
        return Bottom;
    }

    public void setBottom(Nodo<T> Bottom) {
        this.Bottom = Bottom;
    }

    public Nodo<T> getTop() {
        return Top;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public void setTop(Nodo<T> Top) {
        this.Top = Top;
    }

}
