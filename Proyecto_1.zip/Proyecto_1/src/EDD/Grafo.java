/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDD;

import Clases.Usuario;

/**
 *
 * @author Nicola
 */
public class Grafo {

    private int numVertices = 0;
    private Lista<Lista<Nodo<Usuario>>> lista_adyacencia = new Lista<>();

    /**
     * Se ingresa un usuario y crea un vertice en el grafo con esa informacion
     *
     * @param nuevoV
     */
    public void AgregarVertice(Usuario nuevoV) {
        this.numVertices += 1;
        this.lista_adyacencia.Append(new Lista<>());
        Lista<Nodo<Usuario>> Aux = this.lista_adyacencia.getpLast().getData();
        Nodo<Usuario> nuevo = new Nodo(nuevoV);
        Aux.Append((Nodo<Usuario>) nuevo);
    }

    /**
     * recorre la lista de adyacencia del grafo buscando encontrar el usuario y
     * retornando su lista de relaciones
     *
     * @param id
     * @return
     */
    public Lista BuscarUsuario(int id) {
        Nodo<Lista<Nodo<Usuario>>> Aux = this.lista_adyacencia.getpFirst();
        Lista<Nodo<Usuario>> lista_relaciones = Aux.getData();
        while (id != lista_relaciones.getpFirst().getData().getData().getId()) {
            Aux = Aux.getpNext();
            lista_relaciones = Aux.getData();
        }
        return lista_relaciones;
    }

    /**
     * Se ingresa 2 id de usuarios los cuales seran relacionados y se buscaran
     * en el grafo y añadira dicha arista ponderada en ambos sentidos
     *
     * @param id1
     * @param id2
     * @param peso
     */
    public void AgregarArista(int id1, int id2, int peso) {
        if (this.numVertices != 0) {
            Lista inicio = BuscarUsuario(id1);
            Lista destino = BuscarUsuario(id2);
            inicio.AppendPonderado(destino.getpFirst().getData(), peso);
            destino.AppendPonderado(inicio.getpFirst().getData(), peso);
        }
    }

    /**
     * se realiza un recorrido de anchura del grafo ubicando asi las islas que
     * este tiene
     *
     * @return
     */
    public int BFS() {
        int isla = 0;
        if (!this.isEmpty()) {
            boolean no_visitado = false;
            int index = -1;
            isla = 0;
            Object[][] visitados = new Object[this.numVertices][2];
            Nodo<Lista<Nodo<Usuario>>> Aux = this.lista_adyacencia.getpFirst();
            Cola<Usuario> vertices_vecinos = new Cola<>();
            Cola<Usuario> vertices_visitados = new Cola<>();
            Nodo<Nodo<Usuario>> nodoraiz = Aux.getData().getpFirst();
            vertices_vecinos.encolar(nodoraiz.getData().getData());
            while ((index + 1) != numVertices) {
                isla += 1;
                while (!vertices_vecinos.isEmpty()) {
                    Nodo<Nodo<Usuario>> nodo_vertice = BuscarUsuario(vertices_vecinos.getHead().getData().getId()).getpFirst();
                    while (nodo_vertice.getpNext() != null) {
                        nodo_vertice = nodo_vertice.getpNext();
                        if (!(vertices_vecinos.enLaCola(nodo_vertice.getData().getData())) && !(vertices_visitados.enLaCola(nodo_vertice.getData().getData()))) {
                            vertices_vecinos.encolar(nodo_vertice.getData().getData());
                        }
                    }
                    int escape = vertices_visitados.getSize();
                    vertices_visitados.encolar(vertices_vecinos.getHead().getData());
                    vertices_vecinos.Desencolar();
                    if (escape == vertices_visitados.getSize()) {
                        vertices_vecinos.Empty();
                    }
                }
                while (!vertices_visitados.isEmpty()) {
                    index += 1;
                    visitados[index][0] = vertices_visitados.getHead().getData();
                    visitados[index][1] = isla;
                    vertices_visitados.Desencolar();
                }
                while (Aux != null) {
                    for (int i = 0; i <= index; i++) {
                        if (Aux.getData().getpFirst().getData().getData().equals(visitados[i][0])) {
                            no_visitado = false;
                            break;
                        }
                        no_visitado = true;
                    }
                    if (no_visitado) {
                        vertices_vecinos.encolar(Aux.getData().getpFirst().getData().getData());
                        break;
                    }
                    Aux = Aux.getpNext();
                }
            }

        }
        return isla;
    }

    /**
     * se realiza un recorrido de profundidad del grafo ubicando asi las islas
     * que ese tiene
     *
     * @return
     */
    public int DFS() {
        int isla = 0;
        if (!this.isEmpty()) {
            boolean sin_vecinos = true;
            boolean no_visitado = false;
            int index = -1;
            isla = 0;
            Object[][] visitados = new Object[this.numVertices][2];
            Nodo<Lista<Nodo<Usuario>>> Aux = this.lista_adyacencia.getpFirst();
            Pila<Usuario> vertices_vecinos = new Pila<>();
            Pila<Usuario> vertices_visitados = new Pila<>();
            Nodo<Nodo<Usuario>> nodoraiz = Aux.getData().getpFirst();
            vertices_vecinos.apilar(nodoraiz.getData().getData());
            while ((index + 1) != numVertices) {
                isla += 1;
                while (!vertices_vecinos.isEmpty()) {
                    Nodo<Nodo<Usuario>> nodo_vertice = BuscarUsuario(vertices_vecinos.getTop().getData().getId()).getpFirst();

                    while (nodo_vertice.getpNext() != null) {
                        nodo_vertice = nodo_vertice.getpNext();
                        if (!(vertices_vecinos.enLaPila(nodo_vertice.getData().getData())) && !(vertices_visitados.enLaPila(nodo_vertice.getData().getData()))) {
                            vertices_vecinos.apilar(nodo_vertice.getData().getData());
                            sin_vecinos = false;
                            break;
                        }
                        sin_vecinos = true;
                    }
                    if (sin_vecinos) {
                        int escape = vertices_visitados.getSize();
                        vertices_visitados.apilar(vertices_vecinos.getTop().getData());
                        vertices_vecinos.Desapilar();
                        if (escape == vertices_visitados.getSize()) {
                            vertices_vecinos.Empty();
                        }
                    }
                }
                while (!vertices_visitados.isEmpty()) {
                    index += 1;
                    visitados[index][0] = vertices_visitados.getTop().getData();
                    visitados[index][1] = isla;
                    vertices_visitados.Desapilar();
                }
                while (Aux != null) {
                    for (int i = 0; i <= index; i++) {
                        if (Aux.getData().getpFirst().getData().getData().equals(visitados[i][0])) {
                            no_visitado = false;
                            break;
                        }
                        no_visitado = true;
                    }
                    if (no_visitado) {
                        vertices_vecinos.apilar(Aux.getData().getpFirst().getData().getData());
                        break;
                    }
                    Aux = Aux.getpNext();
                }
            }
        }
        return isla;
    }

    /**
     * se elimina la relacion entre dos usuarios de la lista de relaciones de
     * cada uno
     *
     * @param id1
     * @param id2
     */
    public void eliminarArista(int id1, int id2) {
        if (this.numVertices != 0) {
            Lista inicio = BuscarUsuario(id1);
            Lista destino = BuscarUsuario(id2);
            inicio.deleteUsuario(destino.getpFirst().getData());
            destino.deleteUsuario(inicio.getpFirst().getData());
        }
    }

    /**
     * se eliminan todas las relaciones que se tienen con el usuario a eliminar
     * y luego se elimna este usuario de la lista de adyacencia del grafo
     *
     * @param id
     */
    public void eliminarVertice(int id) {
        if (this.numVertices != 0) {
            Cola vecinos = new Cola();

            Lista<Nodo<Usuario>> vertice = BuscarUsuario(id);
            Nodo<Nodo<Usuario>> Aux = vertice.getpFirst();
            while (Aux.getpNext() != null) {
                Aux = Aux.getpNext();
                vecinos.encolar(Aux.getData().getData().getId());
            }
            while (!vecinos.isEmpty()) {
                eliminarArista(vertice.getpFirst().getData().getData().getId(), (int) vecinos.getHead().getData());
                vecinos.Desencolar();
            }
            this.lista_adyacencia.deleteUsuario(vertice);
        }
    }

    public boolean isEmpty() {
        return this.numVertices == 0;
    }

    public String mostrarUsuarios() {
        String reescritura = "";
        if (this.numVertices != 0) {

            Nodo<Lista<Nodo<Usuario>>> Aux = this.lista_adyacencia.getpFirst();
            while (Aux != null) {
                reescritura += "ID: " + Aux.getData().getpFirst().getData().getData().getId() + ", Username: " + Aux.getData().getpFirst().getData().getData().getName() + "\n";
                Aux = Aux.getpNext();
            }
        }
        return reescritura;
    }

    public String identificarPuentes() {
        String puentes= "Puentes:\n";
        Pila usuariosguardados = new Pila();
int islas=this.BFS();
        if (!this.isEmpty()) {
            Nodo<Lista<Nodo<Usuario>>> Aux = this.getLista_adyacencia().getpFirst();
            while (Aux != null) {
                Lista<Nodo<Usuario>> lista_vertices = Aux.getData();
                Usuario usuario = lista_vertices.getpFirst().getData().getData();
                Nodo<Nodo<Usuario>> vecino = lista_vertices.getpFirst();
                int j= lista_vertices.getSize()-1;
                for (int i = 0; i <j ; i++) {
                    if (vecino.getpNext()!=null) {
                    vecino = vecino.getpNext();
                    }
                    if (!(usuariosguardados.enLaPila(vecino.getData().getData()))) {
                        int peso=vecino.getWeight();
                        int temp = vecino.getData().getData().getId();
                        this.eliminarArista(usuario.getId(),vecino.getData().getData().getId());
                        if (this.BFS()!=islas) {
                            puentes+=usuario.getId()+","+temp+","+vecino.getWeight()+"\n";
                        }
                        this.AgregarArista(usuario.getId(), temp, peso);
                    }
                }
                usuariosguardados.apilar(usuario);
                Aux = Aux.getpNext();
            }
        }
        return puentes; 
    }

    public void Imprimir() {
        if (this.numVertices != 0) {
            Nodo<Lista<Nodo<Usuario>>> Aux = this.lista_adyacencia.getpFirst();
            for (int i = 0; i < this.numVertices; i++) {
                Lista<Nodo<Usuario>> sublista_adyacencia = Aux.getData();
                Nodo<Nodo<Usuario>> nodovertice = sublista_adyacencia.getpFirst();
                while (nodovertice != null) {
                    Nodo<Usuario> mini = nodovertice.getData();
                    System.out.print(mini.getData().getName());
                    System.out.print("->");
                    nodovertice = nodovertice.getpNext();
                }
                System.out.println("");
                System.out.println("|");
                Aux = Aux.getpNext();
            }
        }
    }

    public int getNumVertices() {
        return numVertices;
    }

    public void setNumVertices(int numVertices) {
        this.numVertices = numVertices;
    }

    public Lista<Lista<Nodo<Usuario>>> getLista_adyacencia() {
        return lista_adyacencia;
    }

    public void setLista_adyacencia(Lista<Lista<Nodo<Usuario>>> lista_adyacencia) {
        this.lista_adyacencia = lista_adyacencia;
    }

}
