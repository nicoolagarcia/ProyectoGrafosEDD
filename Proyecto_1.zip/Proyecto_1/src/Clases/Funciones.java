package Clases;

import EDD.Grafo;
import EDD.Lista;
import EDD.Nodo;
import EDD.Pila;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author Nicola
 */
public class Funciones {
private String path= "test\\usuarios.txt";
    /**
     * recorre el grafo y mediante el va generando un string que luego sera escrito en un txt
     * @param usuarios
     */
    public void escribir_txt(Grafo usuarios) {
        String reescritura = "Usuarios\n";
        String copiarelaciones = "Relaciones\n";
        Pila usuariosguardados=new Pila();
        try {
        if (!usuarios.isEmpty()) {
            Nodo<Lista<Nodo<Usuario>>> Aux = usuarios.getLista_adyacencia().getpFirst();
            while (Aux != null) {
                Lista<Nodo<Usuario>> lista_vertices = Aux.getData();
                Usuario usuario = lista_vertices.getpFirst().getData().getData();
                reescritura += usuario.getId() + "," + usuario.getName() + "\n";
                Nodo<Nodo<Usuario>> vecino = lista_vertices.getpFirst().getpNext();
                while(vecino!=null){
                    if(!(usuariosguardados.enLaPila(vecino.getData().getData()))){
                        copiarelaciones+=usuario.getId()+","+vecino.getData().getData().getId()+","+vecino.getWeight()+"\n";
                    }
                    vecino=vecino.getpNext();
                }
                usuariosguardados.apilar(usuario);
                Aux = Aux.getpNext();
            }
            reescritura += copiarelaciones;
        }
            PrintWriter pw = new PrintWriter(path);
            pw.print(reescritura);
            pw.close();
            JOptionPane.showMessageDialog(null, "Se ha actualizado efectivamente");

        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "El Grafo esta vacio, vuelva a intentar luego");

        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error, por favor vuelva a intentar");

        } 
    }

    /**
     * Lee el txt y lo convierte en grafo
     * @return
     */
    public Grafo leer_txt() {
        Grafo usuarios= new Grafo();
        String line;
        String texto = "";
        JFileChooser buscador = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos de texto", "txt");
        buscador.setFileFilter(filter);
        boolean txtvalido=false;
while(!txtvalido){
        int returnValue = buscador.showOpenDialog(null);
        while (returnValue != JFileChooser.APPROVE_OPTION) {
            returnValue = buscador.showOpenDialog(null);
        }

        File selectedFile = buscador.getSelectedFile();
        String filePath = selectedFile.getAbsolutePath();

        if (filePath.endsWith(".txt")) {
            txtvalido = true;
        }else{
JOptionPane.showMessageDialog(null,"Archivo inválido. Por favor, seleccione un archivo de texto.");
}
    }
        path = buscador.getSelectedFile().getAbsolutePath();
        File file = new File(path);
        try {
            if (!file.exists()) {
                file.createNewFile();
            } else {
                FileReader fr = new FileReader(file);
                BufferedReader br = new BufferedReader(fr);
                while ((line = br.readLine()) != null) {
                    if (!line.isEmpty()) {
                        texto += line + "\n";
                    }
                }
                if (!"".equals(texto)) {
                    String seccion = null;
                    String[] linea_texto = texto.split("\n");
                    for (int i = 0; i < linea_texto.length; i++) {
                        String[] partelinea_texto = linea_texto[i].split(",");
                        if (seccion == "Usuarios") {
                            if (linea_texto[i].equalsIgnoreCase( "Relaciones")) {
                                seccion = "Relaciones";
                            } else {
                                usuarios.AgregarVertice(new Usuario(Integer.parseInt(partelinea_texto[0].strip()), partelinea_texto[1].strip()));

                            }
                        } else if (seccion == "Relaciones") {
                            usuarios.AgregarArista(Integer.parseInt(partelinea_texto[0].strip()), Integer.parseInt(partelinea_texto[1].strip()), Integer.parseInt(partelinea_texto[2].strip()));
                        } else {
                            if (linea_texto[i].equalsIgnoreCase("Usuarios") ) {
                                seccion = "Usuarios";
                            }
                        }
                    }
                }
                br.close();
            JOptionPane.showMessageDialog(null, "Lectura exitosa");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error, por favor vuelva a intentar");
        }
        return usuarios;
    }
    
}

