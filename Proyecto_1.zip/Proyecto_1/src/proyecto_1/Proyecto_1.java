/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto_1;

import Clases.Funciones;
import Clases.Usuario;
import EDD.Grafo;
import Interfaces_Graficas.Ventana_1;
import java.io.PrintWriter;
import javax.swing.JFileChooser;

/**
 *
 * @author Nicola
 */
public class Proyecto_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Grafo migrafo = new Grafo();
        Ventana_1 menu= new Ventana_1(migrafo);
//        Funciones funcion=new Funciones();
//        migrafo=funcion.leer_txt();
//        funcion.escribir_txt(migrafo);

//        Usuario user;
//        user = new Usuario(12, "nicola"); 
//        migrafo.AgregarVertice(user);
//        user = new Usuario(10, "ana");
//        migrafo.AgregarVertice(user);
//        user = new Usuario(1, "jose"); 
//        migrafo.AgregarVertice(user);
//        user = new Usuario(2, "manu");
//        migrafo.AgregarVertice(user);
//        migrafo.AgregarArista(10, 12, 8);
//        migrafo.AgregarArista(10, 1, 2);
//        migrafo.AgregarArista(1, 12, 1);
//migrafo.Imprimir();
//        
//        System.out.println(migrafo.BFS());
//        System.out.println(migrafo.DFS());  
//        System.out.println(migrafo.mostrarUsuarios());
        

    }

}
